import java.time.LocalDate;
import java.time.Period;

public class Plant {
	
	// Instance Variables
	private String plantName; //name of plant
	private Period daysBeforeLastFrost; //# days before last frost to plant this plant
	private LocalDate dateToStartSeed; //lastFrostDate - daysBeforeLastFrost
	private double inchesBetweenPlants; 
	private double inchesBetweenRows;
	private String inOrOut; //start indoors or outdoors
	private String[] plantsLiked; //list of good companion plants
	private String[] plantsDisliked; //list of plants this plant doesn't like
	
	private static String[] plantFlagList; //array of the plants the user entered
	private static Plant[] arrayOfPlantInstances; //the array of the actual plants
	private static int countOfPlantInstances = 0; //number of plant instances
	private static int plantArrayIndex = 0; //counter for initializing instance array
	private static StringBuilder listOfAllLikedPlants = new StringBuilder(""); //includes duplicates, we will need this for companion sorting
	private static StringBuilder listOfAllDislikedPlants = new StringBuilder(""); //includes duplicates, we will need this for companion sorting
	
	private static boolean beanFlag = false;
	private static boolean poleBeanFlag = false;
	private static boolean beetFlag = false;
	private static boolean broccoliFlag = false;
	private static boolean cabbageFlag = false;
	private static boolean carrotFlag = false;
	private static boolean cauliflowerFlag = false;
	private static boolean celeryFlag = false;
	private static boolean cornFlag = false;
	private static boolean cucumberFlag = false;
	private static boolean eggplantFlag = false;
	private static boolean kaleFlag = false;
	private static boolean lettuceFlag = false;
	private static boolean cantaloupeFlag = false;
	private static boolean okraFlag = false;
	private static boolean onionFlag = false;
	private static boolean peaFlag = false;
	private static boolean bellPepperFlag = false;
	private static boolean radishFlag = false;
	private static boolean spinachFlag = false;
	private static boolean squashFlag = false;
	private static boolean tomatoFlag = false;
	private static boolean turnipFlag = false;
	private static boolean watermelonFlag = false;
	private static boolean basilFlag = false;

	//constructor for instances of a plant with likes AND dislikes
	public Plant (String plantName,
				  int daysBeforeLastFrost, 
				  double inchesBetweenPlants,
				  double inchesBetweenRows,
				  String inOrOutString,
				  String plantsLikedString, 
				  String plantsDislikedString) {
		this.setPlantName(plantName);
		this.setDaysBeforeLastFrost(Period.ofDays(daysBeforeLastFrost));
		this.setDateToStartSeed(UserData.getLastFrostDate().minus(this.daysBeforeLastFrost));
		this.setInchesBetweenPlants(inchesBetweenPlants);
		this.setInchesBetweenRows(inchesBetweenRows);
		this.setInOrOut(inOrOutString);
		this.setPlantsLiked(plantsLikedString);
		this.setPlantsDisliked(plantsDislikedString);
	}

	//constructor for instances of a plant with only likes
	public Plant (String plantName,
			  int daysBeforeLastFrost, 
			  double inchesBetweenPlants,
			  double inchesBetweenRows, 
			  String inOrOutString,
			  String plantsLikedString) {
		this.setPlantName(plantName);
		this.setDaysBeforeLastFrost(Period.ofDays(daysBeforeLastFrost));
		this.setDateToStartSeed(UserData.getLastFrostDate().minus(this.daysBeforeLastFrost));
		this.setInchesBetweenPlants(inchesBetweenPlants);
		this.setInchesBetweenRows(inchesBetweenRows);
		this.setInOrOut(inOrOutString);
		this.setPlantsLiked(plantsLikedString);
	}
	
	public static void printAllPlantChoices() {
		
		String[] plantChoiceList = {"bean", "pole bean", "beet", "broccoli", "cabbage", "carrot", 
				"cauliflower", "celery", "corn", "cucumber", "eggplant", "kale", "lettuce", 
				"cantaloupe", "okra", "onion", "pea", "bell pepper", "radish", "spinach", 
				"squash", "tomato", "turnip", "watermelon", "basil"};
		
    	System.out.print("\nThis is a list of plants you can plant: \n\n");
    	
		for (int i = 0; i < plantChoiceList.length; i++)
		{
			if ((i % 6 == 0) && (i != 0)) {
				System.out.println("");
			}
			System.out.printf("%-12s", WordUtils.capitalizeFully(plantChoiceList[i]));
		}
		System.out.print("\n\nEnter the plants you want to plant separated by a comma and space ( \", \" ): \n");
	}

	//Prints info about each plant
	public String toString() {
			System.out.print("Start " + this.getPlantName() + " seeds " + this.getInOrOut() + " on "  + this.getDateToStartSeed() + ".\n" +
		    	"Allow " + this.getInchesBetweenPlants() + " inches between plants and " +
				this.getInchesBetweenRows() + " inches between rows when planting.\n" +
		    	"Try to plant near: ");
		    for (String plantLiked : this.plantsLiked) {
		    	if (plantLiked.equalsIgnoreCase(this.plantsLiked[this.plantsLiked.length - 1])) {
		    		System.out.print(plantLiked + ".");
		    	}	
		    	else {
		    		System.out.print(plantLiked + ", ");
		    	}
		    }
		    if (this.plantsDisliked != null) {
		    	System.out.print("\nTry to avoid: ");
		    	for (String plantDisLiked : this.plantsDisliked) {
			    	if (plantDisLiked.equalsIgnoreCase(this.plantsDisliked[this.plantsDisliked.length - 1])) {
			    		System.out.print(plantDisLiked + ".");
			    	}	
			    	else {
		    		System.out.print(plantDisLiked + ", ");
			    	}
		    	}
		    }
		    return "\n\n";
	}
	
	//receives string of plant names, breaks them into an array
	public static void setPlantFlagList(String plantFlagString) {
		plantFlagString.toLowerCase();
		Plant.plantFlagList = plantFlagString.split(", ");
	}
	
	//returns list of plant instances
	public static String[] getPlantFlagList() {
		return plantFlagList;
	}
	
	//sets the count of the number of plant instances based on the array of plant names
	public static void setCountOfPlantInstances(String[] plantFlagList) {
		Plant.countOfPlantInstances = Plant.plantFlagList.length;
		Plant.createArrayForPlantInstances(Plant.countOfPlantInstances);
	}
	
	//returns the number of plants
	public static int getCountOfPlantInstances() {
		return countOfPlantInstances;
	}
	
	//goes through the list of plants and calls to instantiate each one (will be put into array)
	public static void changePlantFlags(String[] plantFlagList) {  		
	    for (String plantFlag : plantFlagList) {
	    	switch (plantFlag) {		
	    		case "bean": beanFlag = true; instantiatePlant(plantFlag); break;
	    		case "pole bean": poleBeanFlag = true; instantiatePlant(plantFlag); break;
	    		case "beet": beetFlag = true; instantiatePlant(plantFlag); break;
	    		case "broccoli": broccoliFlag = true; instantiatePlant(plantFlag); break;
	    		case "cabbage": cabbageFlag = true; instantiatePlant(plantFlag); break;
	    		case "carrot": carrotFlag = true; instantiatePlant(plantFlag); break;
	    		case "cauliflower": cauliflowerFlag = true; instantiatePlant(plantFlag); break;
	    		case "celery": celeryFlag = true; instantiatePlant(plantFlag); break;
	    		case "corn": cornFlag = true; instantiatePlant(plantFlag); break;
	    		case "cucumber": cucumberFlag = true; instantiatePlant(plantFlag); break;
	    		case "eggplant": eggplantFlag = true; instantiatePlant(plantFlag); break;
	    		case "kale": kaleFlag = true; instantiatePlant(plantFlag); break;
	    		case "lettuce": lettuceFlag = true; instantiatePlant(plantFlag); break;
	    		case "cantaloupe": cantaloupeFlag = true; instantiatePlant(plantFlag); break;
	    		case "okra": okraFlag = true; instantiatePlant(plantFlag); break;
	    		case "onion": onionFlag = true; instantiatePlant(plantFlag); break;
	    		case "pea": peaFlag = true; instantiatePlant(plantFlag); break;
	    		case "bell pepper": bellPepperFlag = true; instantiatePlant(plantFlag); break;
	    		case "radish": radishFlag = true; instantiatePlant(plantFlag); break;
	    		case "spinach": spinachFlag = true; instantiatePlant(plantFlag); break;
	    		case "squash": squashFlag = true; instantiatePlant(plantFlag); break;
	    		case "tomato": tomatoFlag = true; instantiatePlant(plantFlag); break;
	    		case "turnip": turnipFlag = true; instantiatePlant(plantFlag); break;
	    		case "watermelon": watermelonFlag = true; instantiatePlant(plantFlag); break;
	    		case "basil": basilFlag = true; instantiatePlant(plantFlag); break;
	    	}
	    }
	}
	
	//receives the name of a plant and calls to instantiate it into an array
	public static void instantiatePlant(String plantFlag) {	
			switch (plantFlag) {	
				case "bean": setArrayOfPlantInstances("bean", 0, 3, 18, "outdoors", "carrot|cauliflower|cucumber|cabbage|corn|", "onion|");
    				beanFlag = false; break;
				case "pole bean": setArrayOfPlantInstances("pole bean", 0, 4, 30, "outdoors", "radish|corn|", "beet|");
					poleBeanFlag = false; break;
				case "beet": setArrayOfPlantInstances("beet", 31, 3, 12, "outdoors", "bean|onion|lettuce|cabbage|", "pole bean|");
					beetFlag = false; break;
				case "broccoli": setArrayOfPlantInstances("broccoli", 49, 3, 24, "indoors", "celery|beet|onion|", "tomato|pole bean|");
					broccoliFlag = false; break;
				case "cabbage": setArrayOfPlantInstances("cabbage", 42, 18, 24, "indoors", "celery|onion|", "tomato|pole bean|");
					cabbageFlag = false; break;
				case "carrot": setArrayOfPlantInstances("carrot", 14, 3, 12, "outdoors", "onion|tomato|lettuce|radish|pea|");
					carrotFlag = false; break;					
				case "cauliflower": setArrayOfPlantInstances("cauliflower", 56, 18, 24, "indoors", "celery|onion|", "tomato|pole bean|");
					cauliflowerFlag = false; break;
				case "celery": setArrayOfPlantInstances("celery", 7, 8, 24, "outdoors", "tomato|cauliflower|cabbage|bean|");
					celeryFlag = false; break;
				case "corn": setArrayOfPlantInstances("corn", -10, 4, 12, "outdoors", "pea|bean|cucumber|squash|", "tomato|");
					cornFlag = false; break;
				case "cucumber": setArrayOfPlantInstances("cucumber", 21, 12, 36, "indoors", "corn|bean|pea|radish|");
					cucumberFlag = false; break;
				case "eggplant": setArrayOfPlantInstances("eggplant", 56, 18, 24, "indoors", "bean|");
					eggplantFlag = false; break;
				case "kale": setArrayOfPlantInstances("kale", 21, 8, 18, "outdoors", "celery|beet|onion|", "tomato|pole bean|");
					kaleFlag = false; break;
				case "lettuce": setArrayOfPlantInstances ("lettuce", -5, 6, 12, "outdoors", "onion|cucumber|carrot|radish|");
					lettuceFlag = false; break;
				case "cantaloupe": setArrayOfPlantInstances("cantaloupe", 7, 24, 48, "indoors", "corn|");
					cantaloupeFlag = false; break;
				case "okra": setArrayOfPlantInstances("okra", 14, 12, 24, "indoors", "eggplant|bell pepper|");
					okraFlag = false; break;
				case "onion": setArrayOfPlantInstances("onion", 84, 3, 12, "indoors", "broccoli|cabbage|cauliflower|beet|tomato|lettuce|", "pea|bean|");
					onionFlag = false; break;
				case "pea": setArrayOfPlantInstances("pea", 28, 6, 18, "indoors", "carrot|turnip|radish|cucumber|corn|bean", "onion|");
					peaFlag = false; break;
				case "bell pepper": setArrayOfPlantInstances ("bell pepper", 56, 18, 24, "indoors", "basil|okra|");
					bellPepperFlag = false; break;
				case "radish": setArrayOfPlantInstances("radish", 7, 4, 12, "outdoors", "cucumber|squash|cantaloupe|tomato|bean|pole bean|lettuce|");
					radishFlag = false; break;
				case "spinach": setArrayOfPlantInstances("spinach", 21, 4, 12, "outdoors", "cabbage|celery|eggplant|lettuce|onion|pea|bell pepper|radish|tomato|");
					spinachFlag = false; break;
				case "squash": setArrayOfPlantInstances("squash", -5, 24, 32, "outdoors", "radish|");
					squashFlag = false; break;
				case "tomato": setArrayOfPlantInstances("tomato", 56, 18, 24, "indoors", "onion|carrot|", "broccoli|cauliflower|cabbage|");
					tomatoFlag = false; break;
				case "turnip": setArrayOfPlantInstances("turnip", 21, 3, 12, "outdoors", "pea|");
					turnipFlag = false; break;
				case "watermelon": setArrayOfPlantInstances("watermelon", 28, 24, 48, "indoors", "radish|");
					watermelonFlag = false; break;
				case "basil": setArrayOfPlantInstances("basil", 56, 8, 18, "indoors", "tomato|");
					basilFlag = false; break; 
				default: break;
    		}
	}
	
	//creates empty array with the right number of spots 
	public static void createArrayForPlantInstances(int countOfPlantInstances) {
		Plant[] arrayOfPlantInstances = new Plant[getCountOfPlantInstances()];
		Plant.arrayOfPlantInstances = arrayOfPlantInstances;
	}	
	
	/*
	public static void companionPlantSort(Plant[] arrayOfPlantInstances ) {
		
		Plant[] tempArray = new Plant[getCountOfPlantInstances()];
		tempArray = Plant.createTempArrayForPlantInstances(Plant.countOfPlantInstances);
		
		for (int i = 0; i < arrayOfPlantInstances.length; i++) {
			for (int j = 0; j < arrayOfPlantInstances[i+1].getPlantsDisliked().length; j++) {
				if (arrayOfPlantInstances[i].getPlantName().equalsIgnoreCase(arrayOfPlantInstances[i+1].getPlantsDisliked()[j])) {
					tempArray[0] = arrayOfPlantInstances[i+1];
					
				}
			}
		
		
	}
	}
	
	//return temp/holder array for companion sorting plant instances
	public static Plant[] createTempArrayForPlantInstances(int countOfPlantInstances) {
		Plant[] tempArray = new Plant[getCountOfPlantInstances()];
		return tempArray;
	}	*/
	
	
	
	
	//puts plants with no dislikes into the array of plant instances
	public static void setArrayOfPlantInstances
			  (String plantName,
			  int daysBeforeLastFrost, 
			  double inchesBetweenPlants,
			  double inchesBetweenRows, 
			  String inOrOutString,
			  String plantsLikedString)	{                                                           
	    if (plantArrayIndex < countOfPlantInstances) {
	    	arrayOfPlantInstances[plantArrayIndex] = new Plant(plantName, daysBeforeLastFrost, inchesBetweenPlants, 
	    								inchesBetweenRows, inOrOutString, plantsLikedString);
	    	plantArrayIndex++;
	    }
	}	
	
	//puts plants with likes and dislikes into the array of plant instances
	public static void setArrayOfPlantInstances
	  		(String plantName,
	  		int daysBeforeLastFrost, 
	  		double inchesBetweenPlants,
	  		double inchesBetweenRows, 
	  		String inOrOutString,
	  		String plantsLikedString,
	  		String plantsDislikedString)	{                                                           
		if (plantArrayIndex < countOfPlantInstances) {
			arrayOfPlantInstances[plantArrayIndex] = new Plant(plantName, daysBeforeLastFrost, inchesBetweenPlants, 
								inchesBetweenRows, inOrOutString, plantsLikedString, plantsDislikedString);
			plantArrayIndex++;
		}
	}		
	
	//returns the array of plant instances
	public static Plant[] getArrayOfPlantInstances () {
		return Plant.arrayOfPlantInstances;
	}
	
	//prints out the info for each plant instance in the array
	public static void printArrayOfPlantInstances() {
	    for ( int i = 0; i < Plant.arrayOfPlantInstances.length; i++ ) {
	    	System.out.print(arrayOfPlantInstances[i]);
	    }
	}
	
	//sets plant name
	private void setPlantName(String plantName) {
		this.plantName = plantName;		
	}
	
	//returns plant name
	public String getPlantName() {
		return this.plantName;		
	}
	
	//sets the number of days before last frost to plant the plant
	public void setDaysBeforeLastFrost(Period daysBeforeLastFrost) {
		this.daysBeforeLastFrost = daysBeforeLastFrost;
	}
	
	//returns the number of days before last frost to plant the plant
	public Period getDaysBeforeLastFrost() {
		return this.daysBeforeLastFrost;
	}
	
	//sets the number of inches between each plant for a particular type of plant
	public void setInchesBetweenPlants(double inchesBetweenPlants) {
		this.inchesBetweenPlants = inchesBetweenPlants;
	}
	
	//returns the number of inches between each plant for a particular type of plant
	public double getInchesBetweenPlants() {
		return this.inchesBetweenPlants;
	}
	
	//sets the number of inches between rows for a particular type of plant
	public void setInchesBetweenRows(double inchesBetweenRows) {
		this.inchesBetweenRows = inchesBetweenRows;
	}
	
	//returns the number of inches between rows for a particular type of plant
	public double getInchesBetweenRows() {
		return this.inchesBetweenRows;
	}	
	
	//takes user's last frost date, and the number of days before the last frost that each plant
	//should be planted, and sets a date to plant that plant
	public void setDateToStartSeed(LocalDate dateToStartSeed) {
		this.dateToStartSeed = dateToStartSeed;
	}
	
	//returns a date to plant this plant
	public LocalDate getDateToStartSeed() {
		return this.dateToStartSeed;
	}
	
	//sets a string "indoors" or "outdoors" depending on whether 
	//a plant does best started indoors or outdoors
	public void setInOrOut(String inOrOutString) {
		this.inOrOut = inOrOutString;		
	}
	
	//returns the indoors/outdoors string
	public String getInOrOut() {
		return this.inOrOut;		
	}
	
	//takes a string with a list of a plant's companion plants
	//then puts them in an array
	public void setPlantsLiked(String plantsLikedString) {
		this.plantsLiked = plantsLikedString.split("\\|");
		setListOfAllLikedPlants(plantsLikedString);
	}
	
	//returns the array of plants that a plant likes
	public String[] getPlantsLiked() {
		return this.plantsLiked;
	}

	//takes a string with a list of a plant's disliked
	//then puts them in an array
	public String[] getPlantsDisliked() {
		return this.plantsDisliked;
	}

	//returns the array of plants that a plant dislikes
	public void setPlantsDisliked(String plantsDislikedString) {
		this.plantsDisliked = plantsDislikedString.split("\\|");
		setListOfAllDislikedPlants(plantsDislikedString);
	}	
	
	//returns a listing of all the liked plants of all the plant instances
	//includes duplicates
	//we will need this for sorting
	public static StringBuilder getListOfAllLikedPlants() {
		return listOfAllLikedPlants;
	}

	//adds more plants to the list of all liked plants including duplicates
	public static void setListOfAllLikedPlants(String plantsLikedString) {
		Plant.listOfAllLikedPlants.append(plantsLikedString);
	}

	//returns a listing of all the disliked plants of all the plant instances
	//includes duplicates
	//we will need this for sorting
	public static StringBuilder getListOfAllDislikedPlants() {
		return listOfAllDislikedPlants;
	}

	//adds more plants to the list of all disliked plants including duplicates
	public static void setListOfAllDislikedPlants(String plantsDislikedString) {
		Plant.listOfAllDislikedPlants.append(plantsDislikedString);
	}

}
