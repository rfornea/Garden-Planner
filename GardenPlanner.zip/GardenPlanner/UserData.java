import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class UserData {
	
	
	private static LocalDate lastFrostDate;         //user's average last frost date based on NC city	
	//private static double gardenLength;             //length of user's garden
	//private static double gardenWidth;              //width of user's garden
	
	
	public static String passLastFrostDate(String city) {
		
		String passedLastFrostDate;             //local, just used to return the last frost date
		
		Calendar now = Calendar.getInstance();      //needed for yearInString
		int year = now.get(Calendar.YEAR);          //needed for yearInString
		String yearInString = String.valueOf(year); //local, just used to get current year for last frost date
		
		switch (city.toLowerCase()) {
			case "albemarle": passedLastFrostDate = "Apr 8 " + yearInString; break;
			case "andrews": passedLastFrostDate = "May 4 " + yearInString; break;
		    case "asheboro": passedLastFrostDate = "Apr 5 " + yearInString; break;
			case "asheville": passedLastFrostDate = "Apr 10 " + yearInString; break;
			case "banner elk": passedLastFrostDate = "May 13 " + yearInString; break;
			case "bent creek": passedLastFrostDate = "May 5 " + yearInString; break;
			case "black mountain": passedLastFrostDate = "Apr 27 " + yearInString; break;
			case "blowing rock": passedLastFrostDate = "May 3 " + yearInString; break;
			case "brevard": passedLastFrostDate = "May 3 " + yearInString; break;
			case "burlington": passedLastFrostDate = "Apr 1 " + yearInString; break;
			case "canton": passedLastFrostDate = "May 4 " + yearInString; break;
			case "celo": passedLastFrostDate = "May 18 " + yearInString; break;
			case "chapel hill": passedLastFrostDate = "Apr 15 " + yearInString; break;
			case "charlotte": passedLastFrostDate = "Apr 2 " + yearInString; break;
			case "clinton": passedLastFrostDate = "Apr 1 " + yearInString; break;
			case "concord": passedLastFrostDate = "Apr 2 " + yearInString; break;	   
			case "coweeta": passedLastFrostDate = "May 7 " + yearInString; break;
			case "cullowhee": passedLastFrostDate = "May 3 " + yearInString; break;
			case "durham": passedLastFrostDate = "Apr 13 " + yearInString; break;
			case "edenton": passedLastFrostDate = "Mar 23 " + yearInString; break;
			case "elizabeth city": passedLastFrostDate = "Mar 31 " + yearInString; break;
			case "enka": passedLastFrostDate = "Apr 21 " + yearInString; break;
			case "fayetteville": passedLastFrostDate = "Apr 2 " + yearInString; break;
			case "franklin": passedLastFrostDate = "May 4 " + yearInString; break;
			case "gastonia": passedLastFrostDate = "Apr 6 " + yearInString; break;
			case "goldsboro": passedLastFrostDate = "Mar 28 " + yearInString; break;
			case "greensboro": passedLastFrostDate = "Apr 8 " + yearInString; break;
			case "greenville": passedLastFrostDate = "Apr 1 " + yearInString; break;
			case "hamlet": passedLastFrostDate = "Apr 9 " + yearInString; break;
			case "hatteras": passedLastFrostDate = "Mar 3 " + yearInString; break;
			case "henderson": passedLastFrostDate = "Apr 21 " + yearInString; break;
			case "hendersonville": passedLastFrostDate = "Apr 26 " + yearInString; break;
			case "hickory": passedLastFrostDate = "Apr 8 " + yearInString; break;
			case "highlands": passedLastFrostDate = "Apr 25 " + yearInString; break;
			case "high point": passedLastFrostDate = "Apr 3 " + yearInString; break;
			case "hot springs": passedLastFrostDate = "Apr 21 " + yearInString; break;
			case "jackson": passedLastFrostDate = "Apr 11 " + yearInString; break;
			case "kinston": passedLastFrostDate = "Mar 29 " + yearInString; break;
			case "laurinburg": passedLastFrostDate = "Mar 20 " + yearInString; break;
			case "lenoir": passedLastFrostDate = "Apr 16 " + yearInString; break;
			case "lexington": passedLastFrostDate = "Mar 31 " + yearInString; break;
			case "lumberton": passedLastFrostDate = "Apr 4 " + yearInString; break;
			case "marion": passedLastFrostDate = "Apr 9 " + yearInString; break;
			case "marshall": passedLastFrostDate = "Apr 29 " + yearInString; break;
			case "maysville": passedLastFrostDate = "Apr 22 " + yearInString; break;
			case "monroe": passedLastFrostDate = "Apr 12 " + yearInString; break;
			case "morehead city": passedLastFrostDate = "Mar 20 " + yearInString; break;
			case "morganton": passedLastFrostDate = "Apr 21 " + yearInString; break;
			case "mount airy": passedLastFrostDate = "Apr 22 " + yearInString; break;
			case "nashville": passedLastFrostDate = "Apr 4 " + yearInString; break;
			case "new bern": passedLastFrostDate = "Mar 22 " + yearInString; break;
			case "new holland": passedLastFrostDate = "Mar 30 " + yearInString; break;
			case "oxford": passedLastFrostDate = "Apr 5 " + yearInString; break;
			case "pisgah forest": passedLastFrostDate = "May 2 " + yearInString; break;
			case "plymouth": passedLastFrostDate = "Apr 13 " + yearInString; break;
			case "raleigh": passedLastFrostDate = "Apr 11 " + yearInString; break;
			case "reidsville": passedLastFrostDate = "Apr 7 " + yearInString; break;
			case "rocky mount": passedLastFrostDate = "Apr 5 " + yearInString; break;
			case "salisbury": passedLastFrostDate = "Apr 9 " + yearInString; break;
			case "sanford": passedLastFrostDate = "Apr 19 " + yearInString; break;
			case "shelby": passedLastFrostDate = "Apr 12 " + yearInString; break;
			case "siler city": passedLastFrostDate = "Apr 26 " + yearInString; break;
			case "smithfield": passedLastFrostDate = "Apr 7 " + yearInString; break;
			case "southport": passedLastFrostDate = "Mar 19 " + yearInString; break;
			case "statesville": passedLastFrostDate = "Apr 23 " + yearInString; break;
			case "tarboro": passedLastFrostDate = "Apr 5 " + yearInString; break;
			case "transou": passedLastFrostDate = "May 15 " + yearInString; break;
			case "tryon": passedLastFrostDate = "Apr 5 " + yearInString; break;
			case "wadesboro": passedLastFrostDate = "Mar 28 " + yearInString; break;
			case "waterville": passedLastFrostDate = "Apr 10 " + yearInString; break;
			case "waynesville": passedLastFrostDate = "May 7 " + yearInString; break;
			case "whiteville": passedLastFrostDate = "Apr 2 " + yearInString; break;
			case "willard": passedLastFrostDate = "Apr 4 " + yearInString; break;
	  		case "williamston": passedLastFrostDate = "Mar 29 " + yearInString; break;
	  		case "wilmington": passedLastFrostDate = "Mar 31 " + yearInString; break;
	  		case "wilson": passedLastFrostDate = "Apr 2 " + yearInString; break;
	  		default: passedLastFrostDate = "Apr 15 " + yearInString; break;  // an average last frost date for all of NC
		}
		
		return passedLastFrostDate;
	}
	
	public static void printAllCities() {
		
		String[] cityList = {"albemarle", "asheboro", "asheville", "banner elk", 
							 "bent creek", "black mountain", "blowing rock", "brevard", "burlington", 
							 "canton", "celo", "chapel hill", "charlotte", "clinton", "concord", 
							 "coweeta", "cullowhee", "durham", "edenton", "elizabeth city", "enka", 
							 "fayetteville", "franklin", "gastonia", "goldsboro", "greensboro", 
							 "greenville", "hamlet", "hatteras", "henderson", "hendersonville",
							 "hickory", "highlands", "high point", "hot springs", "jackson", 
							 "kinston", "laurinburg", "lenoir", "lexington", "lumberton", "marion", 
							 "marshall", "maysville", "monroe", "morehead city", "morganton", "mount airy", 
							 "nashville", "new bern", "new holland", "oxford", "pisgah forest",
							 "plymouth", "raleigh", "reidsville", "rocky mount", "salisbury", 
							 "sanford", "shelby", "siler city", "smithfield", "southport", 
							 "statesville", "tarboro", "transou", "tryon", "wadesboro", "waterville", 
							 "waynesville", "whiteville", "willard", "williamston", "wilmington", "wilson"};
		
    	System.out.print("\nThis is a list of cities in North Carolina: \n\n");
    	
		for (int i = 0; i < cityList.length; i++)
		{
			if ((i % 5 == 0) && (i != 0)) {
				System.out.println("");
			}
			System.out.printf("%-15s", WordUtils.capitalizeFully(cityList[i]));
		}
		System.out.print("\n\nFrom that list, enter your city or the one closest to you: \n");
	}
		
		
		
		
		
		
	
	//setter for the user's average last frost date
	//receives this input from the passLastFrostDate method above
	public static void setLastFrostDate(String lastFrostDateInput) { 
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d yyyy");
		lastFrostDate = LocalDate.parse(lastFrostDateInput, formatter);
	}
	
	//getter for the user's average last frost date
	public static LocalDate getLastFrostDate() {
		return lastFrostDate;
	}
	
	/*
	public static void setGardenLength(double gardenLength) {
		UserData.gardenLength = gardenLength * 12;
	}	
	
	public static double getGardenLength() {
		return gardenLength;
	}
	
	public static void setGardenWidth(double gardenWidth) {
		UserData.gardenWidth = gardenWidth * 12;
	}

	public static double getGardenWidth() {
		return gardenWidth;
	}
	
	public static void determineLargerSide_LengthOrWidth() {
		if (UserData.getGardenLength() > UserData.getGardenWidth())
			UserData.allotGardenSpacePerPlant(UserData.getGardenLength(), UserData.getGardenWidth());
		else
			UserData.allotGardenSpacePerPlant(UserData.getGardenWidth(), UserData.getGardenLength());
	}
	
	public static void allotGardenSpacePerPlant(double largerSide, double smallerSide) {
		double inchesOfLargerSidePerPlant = Plant.getCountOfPlantInstances() / largerSide;
		double inchesOfGardenAreaPerPlant = inchesOfLargerSidePerPlant * smallerSide;
	}
	*/

	public static void welcomeMessage() {
		System.out.print("\nWelcome to the North Carolina Garden Planner!\n");
		System.out.print("\nThis application will calculate your average last frost date"
				+ " based on your city in North Carolina.\n");
		System.out.print("\nThen you will be asked to input a list of plants you'd like to plant, \n"
				+ "and the application will advise you when to start seeds for that plant (based on \n"
				+ "your average last frost date).  It will also advise you which plants make good \n"
				+ "companion plants for that plant, and which plants to avoid planting by.\n");
		System.out.print("\nLet's get started!");		
	}
	
	public static void enterToContinue() {
		System.out.print("\nPress 'enter' to continue: \n");		
	}
}
