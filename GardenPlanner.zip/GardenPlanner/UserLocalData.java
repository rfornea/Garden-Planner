import java.time.LocalDate;

public class UserLocalData {
	
	private String cityName;
	private int zip;
	private LocalDate lastFrostDate;


	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public LocalDate getLastFrostDate() {
		return lastFrostDate;
	}

	public void setLastFrostDate(LocalDate lastFrostDate) {
		this.lastFrostDate = lastFrostDate;
	}
}
