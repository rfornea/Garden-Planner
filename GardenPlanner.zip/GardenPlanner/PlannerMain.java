import java.util.Scanner;

public class PlannerMain {
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		
		UserData.welcomeMessage();
		
		UserData.printAllCities();
		
		UserData.setLastFrostDate(UserData.passLastFrostDate(in.nextLine().trim()));
		System.out.println("\nYour average last frost date is: " + UserData.getLastFrostDate());
		
		Plant.printAllPlantChoices();
		
		/* The next three statements seem unnecessarily convoluted.  I have left it that way
		 * because I will need those methods when I expand on the program later.  As of now
		 * everything still works fine.  
		 */		
		Plant.setPlantFlagList(in.nextLine().trim());
		Plant.setCountOfPlantInstances(Plant.getPlantFlagList());
		Plant.changePlantFlags(Plant.getPlantFlagList());
		
		System.out.println(); 
	    for (Plant plantToPlant : Plant.getArrayOfPlantInstances()) {
	    	System.out.print(plantToPlant);
	    }
	    
	    /*System.out.println("All of the liked plants are:  " + Plant.getListOfAllLikedPlants() + 
	    		" Total of " + Plant.getListOfAllLikedPlants().length() + " characters");
	    System.out.println("All of the disliked plants are:  " + Plant.getListOfAllDislikedPlants() +
	    		" Total of " + Plant.getListOfAllDislikedPlants().length() + " characters");*/
		
	    /*
		 * System.out.println("Enter the length of your garden in feet: ");
		 
		UserData.setGardenLength(in.nextDouble());
		
		System.out.println("Enter the width of your garden in feet: ");
		UserData.setGardenWidth(in.nextDouble());
		*/
	    
		in.close();
		System.exit(0);
	}
}
